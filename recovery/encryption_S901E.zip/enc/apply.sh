#!/system/bin/sh
log() { echo "$1"; }
FLAG=",keydirectory=/metadata/vold/metadata_encryption"
patch_file() {
  f="$1"
  [ -f "$f" ] || return 1
  tmp="$f.tmp"
  awk -v flag="$FLAG" '
    $0 ~ /userdata/ && $0 !~ /^[[:space:]]*#/ && index($0, "keydirectory=") == 0 {
      sub(/[ \t\r]+$/, "")
      print $0 flag
      next
    }
    { print }
  ' "$f" > "$tmp" || return 1
  cat "$tmp" > "$f"
  rm -f "$tmp"
  log "patched $f"
  grep userdata "$f"
  return 0
}
found=""
for c in /vendor /system_root/vendor /mnt/vendor; do
  if [ -f "$c/etc/fstab.qcom" ]; then
    found="$c/etc/fstab.qcom"
    break
  fi
done
if [ -z "$found" ]; then
  mkdir -p /mnt/vendor
  for dev in /dev/block/mapper/vendor /dev/block/dm-1 /dev/block/by-name/vendor; do
    [ -e "$dev" ] || continue
    mount -t erofs -o rw "$dev" /mnt/vendor 2>/dev/null || mount -t f2fs -o rw "$dev" /mnt/vendor 2>/dev/null || mount -o rw "$dev" /mnt/vendor 2>/dev/null || continue
    if [ -f /mnt/vendor/etc/fstab.qcom ]; then
      found=/mnt/vendor/etc/fstab.qcom
      break
    fi
    umount /mnt/vendor 2>/dev/null || true
  done
fi
if [ -z "$found" ]; then
  log "vendor fstab not found"
  exit 1
fi
log "fstab $found"
patch_file "$found" || exit 1
sync
log "encryption on"
exit 0
