#!/sbin/sh
LOG=/tmp/rest_debloat.log
: > "$LOG"
log() {
  echo "$1"
  echo "$1" >> "$LOG"
}
canon() {
  out=$(readlink -f "$1" 2>/dev/null) || out=""
  if [ -n "$out" ]; then
    echo "$out"
  else
    echo "$1"
  fi
}
open_part() {
  name="$1"
  fstype="$2"
  RESULT=""
  dev=""
  for cand in \
    /dev/block/mapper/$name \
    /dev/block/by-name/$name \
    /dev/block/bootdevice/by-name/$name \
    /dev/block/platform/soc/1d84000.ufshc/by-name/$name
  do
    if [ -e "$cand" ]; then
      dev="$cand"
      break
    fi
  done
  if [ -z "$dev" ]; then
    log "no device $name"
    return 1
  fi
  blockdev --setrw "$dev" 2>/dev/null
  mp=""
  want=$(canon "$dev")
  while read -r src dst _rest; do
    case "$src" in
      /dev/*) ;;
      *) continue ;;
    esac
    got=$(canon "$src")
    if [ "$got" = "$want" ] || [ "$src" = "$dev" ]; then
      mp="$dst"
      break
    fi
  done < /proc/mounts
  if [ -n "$mp" ]; then
    mount -o remount,rw "$mp" 2>/dev/null
    if touch "$mp/.hsui_rw" 2>/dev/null; then
      rm -f "$mp/.hsui_rw"
      RESULT="$mp"
      log "$name rw $mp"
      return 0
    fi
    log "remount failed $name"
    umount "$mp" 2>/dev/null || umount -l "$mp" 2>/dev/null
  fi
  mnt="/mnt/$name"
  mkdir -p "$mnt"
  if [ "$fstype" = "ext4" ]; then
    mount -t ext4 -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || mount -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || { log "mount failed $name"; return 1; }
  else
    mount -t f2fs -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || mount -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || { log "mount failed $name"; return 1; }
  fi
  if touch "$mnt/.hsui_rw" 2>/dev/null; then
    rm -f "$mnt/.hsui_rw"
    RESULT="$mnt"
    log "$name rw $mnt"
    return 0
  fi
  log "still read-only $name"
  return 1
}
app_root() {
  base="$1"
  if [ -d "$base/system/priv-app" ] || [ -d "$base/system/app" ]; then
    echo "$base/system"
    return 0
  fi
  if [ -d "$base/priv-app" ] || [ -d "$base/app" ]; then
    echo "$base"
    return 0
  fi
  log "empty filesystem $base"
  return 1
}
wipe_tree() {
  root="$1"
  tag="$2"
  shift 2
  for rel in "$@"; do
    target="$root/$rel"
    if [ ! -e "$target" ] && [ ! -L "$target" ]; then
      log "absent $tag$rel"
      continue
    fi
    rm -rf "$target"
    if [ -e "$target" ] || [ -L "$target" ]; then
      log "failed $tag$rel"
      echo x >> /tmp/hsui_debloat_fail
    else
      log "removed $tag$rel"
    fi
  done
}
mount_data() {
  if grep -q ' /data ' /proc/mounts; then
    return 0
  fi
  mkdir -p /data
  for dev in \
    /dev/block/by-name/userdata \
    /dev/block/bootdevice/by-name/userdata \
    /dev/block/mapper/userdata
  do
    if [ ! -e "$dev" ]; then
      continue
    fi
    blockdev --setrw "$dev" 2>/dev/null
    mount -t f2fs -o rw,noatime "$dev" /data 2>/dev/null && return 0
    mount -o rw,noatime "$dev" /data 2>/dev/null && return 0
  done
  return 1
}
wipe_data() {
  if ! mount_data; then
    log "userdata not mounted"
    echo x >> /tmp/hsui_debloat_fail
    return 1
  fi
  find /data/app -mindepth 2 -maxdepth 3 -type d > /tmp/hsui_applist 2>/dev/null || true
  while read -r dir; do
    [ -n "$dir" ] || continue
    base=${dir##*/}
    for pkg in "$@"; do
      case "$base" in
        "$pkg"|"$pkg"-*)
          rm -rf "$dir"
          if [ -e "$dir" ]; then
            log "failed data $pkg"
            echo x >> /tmp/hsui_debloat_fail
          else
            log "data $pkg"
          fi
          ;;
      esac
    done
  done < /tmp/hsui_applist
  for pkg in "$@"; do
    rm -rf "/data/data/$pkg" "/data/user/0/$pkg" "/data/user_de/0/$pkg"
    if [ -e "/data/data/$pkg" ] || [ -e "/data/user/0/$pkg" ] || [ -e "/data/user_de/0/$pkg" ]; then
      log "failed data $pkg"
      echo x >> /tmp/hsui_debloat_fail
    fi
  done
}

export PATH="/sbin:/system/bin:${PATH}"
rm -f /tmp/hsui_debloat_fail

open_part system f2fs || exit 1
SYS=$(app_root "$RESULT") || exit 1
log "system $SYS"
wipe_tree "$SYS" "" app/EasterEgg app/BasicDreams app/PhotoTable app/VoiceAccess app/LiveTranscribe priv-app/OmaCP priv-app/AppUpdateCenter priv-app/serviceModeApp_FB priv-app/HwModuleTest app/Cameralyzer app/TetheringAutomation priv-app/BuiltInPrintService app/PrintSpooler app/GooglePrintRecommendationService
open_part product f2fs || exit 1
PROD=$(app_root "$RESULT") || exit 1
log "product $PROD"
wipe_tree "$PROD" "product " priv-app/Velvet priv-app/Turbo priv-app/AndroidAutoStub priv-app/FamilyLinkParentalControls priv-app/AndroidSystemIntelligence priv-app/PrivateComputeServices
open_part prism ext4 || exit 1
PRISM=$(app_root "$RESULT") || exit 1
log "prism $PRISM"
wipe_tree "$PRISM" "prism " app/SwiftKey-market-arm64-v8a-release app/SwiftKeyFactorySettings-samsung
wipe_data com.android.egg com.android.dreams.basic com.android.dreams.phototable com.google.android.googlequicksearchbox com.google.android.apps.turbo com.google.android.apps.accessibility.voiceaccess com.google.audio.hearing.visualization.accessibility.scribe com.google.android.projection.gearhead com.wsomacp com.samsung.android.app.updatecenter com.sec.android.app.servicemodeapp com.sec.android.app.hwmoduletest com.sec.factory.cameralyzer com.sec.automation com.touchtype.swiftkey com.swiftkey.swiftkeyconfigurator com.android.bips com.android.printspooler com.google.android.printservice.recommendation com.google.android.gms.supervision com.google.android.as com.google.android.as.oss

sync
if [ -s /tmp/hsui_debloat_fail ]; then
  log "rest debloat failed"
  exit 1
fi
log "rest debloat ok"
exit 0
