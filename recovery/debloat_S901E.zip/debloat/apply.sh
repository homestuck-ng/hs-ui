#!/sbin/sh
LOG=/tmp/debloat.log
: > "$LOG"
log() {
  echo "$1"
  echo "$1" >> "$LOG"
}
canon() {
  out=$(readlink -f "$1" 2>/dev/null) || out=""
  if [ -n "$out" ]; then
    echo "$out"
  else
    echo "$1"
  fi
}
open_part() {
  name="$1"
  fstype="$2"
  RESULT=""
  dev=""
  for cand in \
    /dev/block/mapper/$name \
    /dev/block/by-name/$name \
    /dev/block/bootdevice/by-name/$name \
    /dev/block/platform/soc/1d84000.ufshc/by-name/$name
  do
    if [ -e "$cand" ]; then
      dev="$cand"
      break
    fi
  done
  if [ -z "$dev" ]; then
    log "no device $name"
    return 1
  fi
  blockdev --setrw "$dev" 2>/dev/null
  mp=""
  want=$(canon "$dev")
  while read -r src dst _rest; do
    case "$src" in
      /dev/*) ;;
      *) continue ;;
    esac
    got=$(canon "$src")
    if [ "$got" = "$want" ] || [ "$src" = "$dev" ]; then
      mp="$dst"
      break
    fi
  done < /proc/mounts
  if [ -n "$mp" ]; then
    mount -o remount,rw "$mp" 2>/dev/null
    if touch "$mp/.hsui_rw" 2>/dev/null; then
      rm -f "$mp/.hsui_rw"
      RESULT="$mp"
      log "$name rw $mp"
      return 0
    fi
    log "remount failed $name"
    umount "$mp" 2>/dev/null || umount -l "$mp" 2>/dev/null
  fi
  mnt="/mnt/$name"
  mkdir -p "$mnt"
  if [ "$fstype" = "ext4" ]; then
    mount -t ext4 -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || mount -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || { log "mount failed $name"; return 1; }
  else
    mount -t f2fs -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || mount -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || { log "mount failed $name"; return 1; }
  fi
  if touch "$mnt/.hsui_rw" 2>/dev/null; then
    rm -f "$mnt/.hsui_rw"
    RESULT="$mnt"
    log "$name rw $mnt"
    return 0
  fi
  log "still read-only $name"
  return 1
}
app_root() {
  base="$1"
  if [ -d "$base/system/priv-app" ] || [ -d "$base/system/app" ]; then
    echo "$base/system"
    return 0
  fi
  if [ -d "$base/priv-app" ] || [ -d "$base/app" ]; then
    echo "$base"
    return 0
  fi
  log "empty filesystem $base"
  return 1
}
wipe_tree() {
  root="$1"
  tag="$2"
  shift 2
  for rel in "$@"; do
    target="$root/$rel"
    if [ ! -e "$target" ] && [ ! -L "$target" ]; then
      log "absent $tag$rel"
      continue
    fi
    rm -rf "$target"
    if [ -e "$target" ] || [ -L "$target" ]; then
      log "failed $tag$rel"
      echo x >> /tmp/hsui_debloat_fail
    else
      log "removed $tag$rel"
    fi
  done
}
mount_data() {
  if grep -q ' /data ' /proc/mounts; then
    return 0
  fi
  mkdir -p /data
  for dev in \
    /dev/block/by-name/userdata \
    /dev/block/bootdevice/by-name/userdata \
    /dev/block/mapper/userdata \
    /dev/block/platform/soc/1d84000.ufshc/by-name/userdata
  do
    if [ ! -e "$dev" ]; then
      continue
    fi
    blockdev --setrw "$dev" 2>/dev/null
    # Plain f2fs only — flash this zip after Format Data and before first boot,
    # while userdata is still unencrypted.
    mount -t f2fs -o rw,noatime "$dev" /data 2>/dev/null && return 0
    mount -o rw,noatime "$dev" /data 2>/dev/null && return 0
  done
  return 1
}
wipe_data() {
  # After Format Data, /data is empty; mounting may still fail if FBE already
  # started. System/product/prism removals are what matter — do not fail the zip.
  if ! mount_data; then
    log "userdata not mounted (ok after format / before first boot)"
    return 0
  fi
  find /data/app -mindepth 2 -maxdepth 3 -type d > /tmp/hsui_applist 2>/dev/null || true
  while read -r dir; do
    [ -n "$dir" ] || continue
    base=${dir##*/}
    for pkg in "$@"; do
      case "$base" in
        "$pkg"|"$pkg"-*)
          rm -rf "$dir"
          if [ -e "$dir" ]; then
            log "failed data $pkg"
            echo x >> /tmp/hsui_debloat_fail
          else
            log "data $pkg"
          fi
          ;;
      esac
    done
  done < /tmp/hsui_applist
  for pkg in "$@"; do
    rm -rf "/data/data/$pkg" "/data/user/0/$pkg" "/data/user_de/0/$pkg"
    if [ -e "/data/data/$pkg" ] || [ -e "/data/user/0/$pkg" ] || [ -e "/data/user_de/0/$pkg" ]; then
      log "failed data $pkg"
      echo x >> /tmp/hsui_debloat_fail
    fi
  done
}

export PATH="/sbin:/system/bin:${PATH}"
rm -f /tmp/hsui_debloat_fail
log "flash after ROM + Format Data, before first boot"
open_part system f2fs || exit 1
SYS=$(app_root "$RESULT") || exit 1
log "system $SYS"
wipe_tree "$SYS" "" priv-app/Bixby app/BixbyWakeup priv-app/BixbyVisionFramework3.5 priv-app/SettingsBixby app/VisionIntelligence3.7 priv-app/SVoiceIME priv-app/BsdService priv-app/SohService priv-app/Finder priv-app/SVCAgent priv-app/YourPhone_P1_5 priv-app/GameTools_Dream priv-app/GameOptimizingService app/ARZone priv-app/AREmoji priv-app/AREmojiEditor app/ARDrawing priv-app/SmartTouchCall priv-app/AvatarEmojiSticker priv-app/StickerFaceARAvatar app/StickerCenter app/MinusOnePage priv-app/ThemeStore priv-app/ThemeCenter priv-app/SamsungAccount priv-app/Routines priv-app/DeXonPC priv-app/KnoxDesktopLauncher priv-app/DesktopModeUiService priv-app/DesktopSystemUI etc/sysconfig/samsungaccount.xml etc/permissions/privapp-permissions-com.osp.app.signin.xml etc/permissions/privapp-permissions-com.samsung.android.app.routines.xml etc/permissions/privapp-permissions-com.samsung.android.themecenter.xml etc/permissions/privapp-permissions-themestore.xml etc/permissions/privapp-permissions-com.sec.android.app.dexonpc.xml etc/permissions/privapp-permissions-com.sec.android.app.desktoplauncher.xml etc/permissions/privapp-permissions-com.sec.android.desktopmode.uiservice.xml etc/permissions/privapp-permissions-com.sec.android.dexsystemui.xml etc/permissions/DesktopSystemUICoreLib_permissions.xml etc/permissions/DesktopSystemUIKnoxLib_permissions.xml etc/default-permissions/default-permissions-com.samsung.android.app.routines.xml etc/default-permissions/default-permissions-com.samsung.android.themestore.xml etc/default-permissions/default-permissions-com.sec.android.dexsystemui.xml priv-app/GalaxyApps_OPEN priv-app/SamsungBilling app/KidsHome_Installer app/GearManagerStub app/DictDiotekForSec priv-app/GpuWatchApp app/SmartSwitchAgent priv-app/SmartSwitchAssistant priv-app/SamsungCloudClient priv-app/DigitalWellbeing priv-app/LinkToWindowsService app/BasicDreams app/PhotoTable app/VoiceAccess app/LiveTranscribe priv-app/AppUpdateCenter app/AppLinker app/BBCAgent app/BGMProvider app/Cameralyzer app/ChromeCustomizations app/DsmsAPK app/EasterEgg app/EasymodeContactsWidget81 app/Fast app/HandwritingService app/HiyaService app/KeyCustomizationInfoBackupService app/MAPSAgent app/NfwLocationPrivacy app/SafetyInformation app/Traceur app/ccinfo priv-app/AutoDoodle priv-app/IAFDManagerService priv-app/ImsLogger priv-app/LedCoverService priv-app/MateAgent priv-app/NetworkDiagnostic priv-app/PeripheralFramework priv-app/RubinVersion33 priv-app/SPPPushClient priv-app/SamsungSmartSuggestions priv-app/SmartThingsKit priv-app/VolumeMonitorProvider_T priv-app/knoxanalyticsagent app/Foundation app/SamsungOne app/AllshareMediaShare app/ClipboardEdge app/DAAgent app/ESEServiceAgent app/EasyOneHand3 priv-app/CocktailBarService_v3.2 priv-app/TaskEdgePanel_v3.2 priv-app/EsimClient priv-app/CMFAFramework priv-app/MultiControlVP6 priv-app/EnhancedAttestationAgent priv-app/KPECore priv-app/MCFDeviceSync app/MdxKitService priv-app/SamsungPositioning priv-app/MobileWips priv-app/SmartManager_v5 priv-app/Crane priv-app/FaceService priv-app/IPService app/CocktailQuickTool priv-app/serviceModeApp_FB priv-app/SoundAlive_T priv-app/IntelligentDynamicFpsService priv-app/AdaptSound_T priv-app/NSFusedLocation_v6.0 priv-app/NSDSWebApp priv-app/SKMSAgent priv-app/OmaCP
open_part system_ext f2fs || exit 1
SYSEXT=$(app_root "$RESULT") || exit 1
log "system_ext $SYSEXT"
wipe_tree "$SYSEXT" "system_ext " priv-app/com.qualcomm.location
open_part prism ext4 || exit 1
PRISM=$(app_root "$RESULT") || exit 1
log "prism $PRISM"
wipe_tree "$PRISM" "prism " app/SwiftKey-market-arm64-v8a-release app/SwiftKeyFactorySettings-samsung app/MDIP-TIM_O2UK_DTDE_VFAU_OPTUSAU_3IT_sdk-30 app/instagram-stub priv-app/MyGalaxy
open_part product f2fs || exit 1
PROD=$(app_root "$RESULT") || exit 1
log "product $PROD"
wipe_tree "$PROD" "product " priv-app/PrivateComputeServices priv-app/Velvet priv-app/AndroidAutoStub priv-app/FamilyLinkParentalControls app/GoogleLocationHistory priv-app/HotwordEnrollmentOKGoogleEx4HEXAGON priv-app/HotwordEnrollmentXGoogleEx4HEXAGON
wipe_data com.samsung.android.bixby.agent com.samsung.android.bixby.wakeup com.samsung.android.bixbyvision.framework com.samsung.android.app.settings.bixby com.samsung.android.visionintelligence com.samsung.android.svoiceime com.samsung.sait.bsdservice com.samsung.sait.sohservice com.samsung.android.app.galaxyfinder com.samsung.android.svcagent com.microsoft.appmanager com.samsung.android.game.gametools com.samsung.android.game.gos com.samsung.android.arzone com.samsung.android.aremoji com.samsung.android.aremojieditor com.samsung.android.ardrawing com.samsung.android.visualars com.sec.android.mimage.avatarstickers com.samsung.android.app.camera.sticker.facearavatar.preload com.samsung.android.stickercenter com.samsung.android.app.spage com.samsung.android.themestore com.samsung.android.themecenter com.osp.app.signin com.samsung.android.app.routines com.sec.android.app.dexonpc com.sec.android.dexsystemui com.sec.android.desktopmode.uiservice com.sec.android.app.desktoplauncher com.sec.android.app.samsungapps com.sec.android.app.billing com.samsung.android.kidsinstaller com.samsung.android.app.watchmanagerstub com.diotek.sec.lookup.dictionary com.samsung.gpuwatchapp com.sec.android.easyMover com.sec.android.easyMover.Agent com.samsung.android.smartswitchassistant com.touchtype.swiftkey com.samsung.android.scloud com.samsung.android.forest com.samsung.android.mdx com.samsung.android.app.tips com.android.dreams.basic com.android.dreams.phototable com.google.android.googlequicksearchbox com.google.android.apps.accessibility.voiceaccess com.google.audio.hearing.visualization.accessibility.scribe com.google.android.projection.gearhead com.samsung.android.app.updatecenter com.google.android.gms.supervision com.amazon.appmanager com.swiftkey.swiftkeyconfigurator com.instagram.android com.mygalaxy com.google.android.gms.location.history com.android.hotwordenrollment.okgoogle com.android.hotwordenrollment.xgoogle com.sec.android.app.applinker com.samsung.android.bbc.bbcagent com.sec.android.app.ve.vebgm com.sec.factory.cameralyzer com.sec.android.app.chromecustomizations com.samsung.android.dsms com.android.egg com.sec.android.widgetapp.easymodecontactswidget com.samsung.android.fast com.samsung.android.sdk.handwriting com.hiya.star com.samsung.android.keycustomizationinfobackupservice com.samsung.android.mapsagent com.sec.location.nfwlocationprivacy com.samsung.safetyinformation com.android.traceur com.sec.android.CcInfo com.sec.android.autodoodle.service com.sec.android.iaft com.sec.imslogger com.sec.android.cover.ledcover com.samsung.android.mateagent com.samsung.android.networkdiagnostic com.samsung.android.peripheral.framework com.samsung.android.rubin.app com.sec.spp.push com.samsung.android.smartsuggestions com.samsung.android.service.stplatform com.sec.android.app.volumemonitorprovider com.samsung.android.knox.analytics.uploader com.google.android.as com.monotype.android.font.foundation com.monotype.android.font.samsungone com.qualcomm.location com.samsung.android.allshare.service.mediashare com.samsung.android.app.clipboardedge com.samsung.android.app.cocktailbarservice com.samsung.android.app.taskedge com.samsung.android.app.telephonyui.esimclient com.samsung.android.cmfa.framework com.samsung.android.da.daagent com.samsung.android.inputshare com.samsung.android.knox.attestation com.samsung.android.knox.kpecore com.samsung.android.mcfds com.samsung.android.mdx.kit com.samsung.android.samsungpositioning com.samsung.android.server.wifi.mobilewips com.samsung.android.sm com.samsung.crane com.samsung.faceservice com.samsung.ipservice com.samsung.ucs.agent.ese com.sec.android.app.quicktool com.sec.android.app.servicemodeapp com.sec.android.app.soundalive com.sec.android.easyonehand com.sec.android.smartfpsadjuster com.sec.hearingadjust com.sec.location.nsflp2 com.sec.vsim.ericssonnsds.webapp com.skms.android.agent com.wsomacp

sync
if [ -s /tmp/hsui_debloat_fail ]; then
  log "debloat failed"
  exit 1
fi
log "debloat ok"
exit 0
