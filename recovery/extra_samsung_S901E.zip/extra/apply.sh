#!/sbin/sh
LOG=/tmp/extra_debloat.log
: > "$LOG"
log() {
  echo "$1"
  echo "$1" >> "$LOG"
}
canon() {
  out=$(readlink -f "$1" 2>/dev/null) || out=""
  if [ -n "$out" ]; then
    echo "$out"
  else
    echo "$1"
  fi
}
open_part() {
  name="$1"
  fstype="$2"
  RESULT=""
  dev=""
  for cand in \
    /dev/block/mapper/$name \
    /dev/block/by-name/$name \
    /dev/block/bootdevice/by-name/$name \
    /dev/block/platform/soc/1d84000.ufshc/by-name/$name
  do
    if [ -e "$cand" ]; then
      dev="$cand"
      break
    fi
  done
  if [ -z "$dev" ]; then
    log "no device $name"
    return 1
  fi
  blockdev --setrw "$dev" 2>/dev/null
  mp=""
  want=$(canon "$dev")
  while read -r src dst _rest; do
    case "$src" in
      /dev/*) ;;
      *) continue ;;
    esac
    got=$(canon "$src")
    if [ "$got" = "$want" ] || [ "$src" = "$dev" ]; then
      mp="$dst"
      break
    fi
  done < /proc/mounts
  if [ -n "$mp" ]; then
    mount -o remount,rw "$mp" 2>/dev/null
    if touch "$mp/.hsui_rw" 2>/dev/null; then
      rm -f "$mp/.hsui_rw"
      RESULT="$mp"
      log "$name rw $mp"
      return 0
    fi
    log "remount failed $name"
    umount "$mp" 2>/dev/null || umount -l "$mp" 2>/dev/null
  fi
  mnt="/mnt/$name"
  mkdir -p "$mnt"
  if [ "$fstype" = "ext4" ]; then
    mount -t ext4 -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || mount -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || { log "mount failed $name"; return 1; }
  else
    mount -t f2fs -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || mount -o rw,noatime "$dev" "$mnt" 2>/dev/null \
      || { log "mount failed $name"; return 1; }
  fi
  if touch "$mnt/.hsui_rw" 2>/dev/null; then
    rm -f "$mnt/.hsui_rw"
    RESULT="$mnt"
    log "$name rw $mnt"
    return 0
  fi
  log "still read-only $name"
  return 1
}
app_root() {
  base="$1"
  if [ -d "$base/system/priv-app" ] || [ -d "$base/system/app" ]; then
    echo "$base/system"
    return 0
  fi
  if [ -d "$base/priv-app" ] || [ -d "$base/app" ]; then
    echo "$base"
    return 0
  fi
  log "empty filesystem $base"
  return 1
}
wipe_tree() {
  root="$1"
  tag="$2"
  shift 2
  for rel in "$@"; do
    target="$root/$rel"
    if [ ! -e "$target" ] && [ ! -L "$target" ]; then
      log "absent $tag$rel"
      continue
    fi
    rm -rf "$target"
    if [ -e "$target" ] || [ -L "$target" ]; then
      log "failed $tag$rel"
      echo x >> /tmp/hsui_debloat_fail
    else
      log "removed $tag$rel"
    fi
  done
}
mount_data() {
  if grep -q ' /data ' /proc/mounts; then
    return 0
  fi
  mkdir -p /data
  for dev in \
    /dev/block/by-name/userdata \
    /dev/block/bootdevice/by-name/userdata \
    /dev/block/mapper/userdata
  do
    if [ ! -e "$dev" ]; then
      continue
    fi
    blockdev --setrw "$dev" 2>/dev/null
    mount -t f2fs -o rw,noatime "$dev" /data 2>/dev/null && return 0
    mount -o rw,noatime "$dev" /data 2>/dev/null && return 0
  done
  return 1
}
wipe_data() {
  if ! mount_data; then
    log "userdata not mounted"
    echo x >> /tmp/hsui_debloat_fail
    return 1
  fi
  find /data/app -mindepth 2 -maxdepth 3 -type d > /tmp/hsui_applist 2>/dev/null || true
  while read -r dir; do
    [ -n "$dir" ] || continue
    base=${dir##*/}
    for pkg in "$@"; do
      case "$base" in
        "$pkg"|"$pkg"-*)
          rm -rf "$dir"
          if [ -e "$dir" ]; then
            log "failed data $pkg"
            echo x >> /tmp/hsui_debloat_fail
          else
            log "data $pkg"
          fi
          ;;
      esac
    done
  done < /tmp/hsui_applist
  for pkg in "$@"; do
    rm -rf "/data/data/$pkg" "/data/user/0/$pkg" "/data/user_de/0/$pkg"
    if [ -e "/data/data/$pkg" ] || [ -e "/data/user/0/$pkg" ] || [ -e "/data/user_de/0/$pkg" ]; then
      log "failed data $pkg"
      echo x >> /tmp/hsui_debloat_fail
    fi
  done
}

export PATH="/sbin:/system/bin:${PATH}"
rm -f /tmp/hsui_debloat_fail

open_part system f2fs || exit 1
SYS=$(app_root "$RESULT") || exit 1
log "system $SYS"
wipe_tree "$SYS" "" priv-app/Bixby app/BixbyWakeup priv-app/BixbyVisionFramework3.5 priv-app/SettingsBixby app/VisionIntelligence3.7 priv-app/SVoiceIME priv-app/BsdService priv-app/SohService priv-app/Finder priv-app/SVCAgent priv-app/YourPhone_P1_5 priv-app/GameTools_Dream priv-app/GameOptimizingService app/ARZone priv-app/AREmoji priv-app/AREmojiEditor app/ARDrawing priv-app/SmartTouchCall priv-app/AvatarEmojiSticker priv-app/StickerFaceARAvatar app/StickerCenter app/MinusOnePage priv-app/ThemeStore priv-app/GalaxyApps_OPEN priv-app/SamsungBilling app/KidsHome_Installer app/GearManagerStub app/DictDiotekForSec priv-app/GpuWatchApp app/SmartSwitchAgent priv-app/SmartSwitchAssistant priv-app/SamsungCloudClient priv-app/DigitalWellbeing priv-app/LinkToWindowsService
open_part prism ext4 || exit 1
PRISM=$(app_root "$RESULT") || exit 1
log "prism $PRISM"
wipe_tree "$PRISM" "prism " app/SwiftKey-market-arm64-v8a-release app/SwiftKeyFactorySettings-samsung
wipe_data com.samsung.android.bixby.agent com.samsung.android.bixby.wakeup com.samsung.android.bixbyvision.framework com.samsung.android.app.settings.bixby com.samsung.android.visionintelligence com.samsung.android.svoiceime com.samsung.sait.bsdservice com.samsung.sait.sohservice com.samsung.android.app.galaxyfinder com.samsung.android.svcagent com.microsoft.appmanager com.samsung.android.game.gametools com.samsung.android.game.gos com.samsung.android.arzone com.samsung.android.aremoji com.samsung.android.aremojieditor com.samsung.android.ardrawing com.samsung.android.visualars com.sec.android.mimage.avatarstickers com.samsung.android.app.camera.sticker.facearavatar.preload com.samsung.android.stickercenter com.samsung.android.app.spage com.samsung.android.themestore com.sec.android.app.samsungapps com.sec.android.app.billing com.samsung.android.kidsinstaller com.samsung.android.app.watchmanagerstub com.diotek.sec.lookup.dictionary com.samsung.gpuwatchapp com.sec.android.easyMover com.sec.android.easyMover.Agent com.samsung.android.smartswitchassistant com.touchtype.swiftkey com.swiftkey.swiftkeyconfigurator com.samsung.android.scloud com.samsung.android.forest com.samsung.android.mdx com.samsung.android.app.tips

sync
if [ -s /tmp/hsui_debloat_fail ]; then
  log "extra samsung failed"
  exit 1
fi
log "extra samsung ok"
exit 0
