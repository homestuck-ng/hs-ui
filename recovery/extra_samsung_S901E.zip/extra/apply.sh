#!/system/bin/sh
log() { echo "$1"; }
find_system() {
  for c in /system_root /system /mnt/system /mnt/sys; do
    if [ -d "$c/system/priv-app" ]; then
      echo "$c/system"
      return 0
    fi
    if [ -d "$c/priv-app" ]; then
      echo "$c"
      return 0
    fi
  done
  return 1
}
SYS=$(find_system)
if [ -z "$SYS" ]; then
  mkdir -p /mnt/sys
  for dev in /dev/block/mapper/system /dev/block/dm-0 /dev/block/by-name/system; do
    [ -e "$dev" ] || continue
    mount -t f2fs -o rw "$dev" /mnt/sys 2>/dev/null || mount -o rw "$dev" /mnt/sys 2>/dev/null || continue
    SYS=$(find_system)
    [ -n "$SYS" ] && break
    umount /mnt/sys 2>/dev/null || true
  done
fi
if [ -z "$SYS" ]; then
  log "system not mounted"
  exit 1
fi
log "system $SYS"
ok=0
for rel in priv-app/Bixby app/BixbyWakeup priv-app/BixbyVisionFramework3.5 priv-app/SettingsBixby app/VisionIntelligence3.7 priv-app/SVoiceIME priv-app/BsdService priv-app/SohService priv-app/Finder priv-app/SVCAgent priv-app/YourPhone_P1_5 priv-app/GameTools_Dream priv-app/GameOptimizingService app/ARZone priv-app/AREmoji priv-app/AREmojiEditor app/ARDrawing priv-app/SmartTouchCall priv-app/AvatarEmojiSticker priv-app/StickerFaceARAvatar priv-app/DressRoom app/StickerCenter app/MinusOnePage priv-app/ThemeStore priv-app/GalaxyApps_OPEN priv-app/SamsungBilling app/KidsHome_Installer app/GearManagerStub app/DictDiotekForSec priv-app/GpuWatchApp app/SmartSwitchAgent priv-app/SmartSwitchAssistant priv-app/SamsungCloudClient priv-app/DigitalWellbeing priv-app/LinkToWindowsService; do
  target="$SYS/$rel"
  if [ -e "$target" ]; then
    rm -rf "$target"
    log "removed $rel"
    ok=$((ok + 1))
  else
    log "absent $rel"
  fi
done
PRISM=""
for c in /prism /system_root/prism /mnt/prism; do
  if [ -d "$c/app" ]; then
    PRISM="$c"
    break
  fi
done
if [ -n "$PRISM" ]; then
  for rel in app/SwiftKey-market-arm64-v8a-release app/SwiftKeyFactorySettings-samsung; do
    target="$PRISM/$rel"
    if [ -e "$target" ]; then
      rm -rf "$target"
      log "removed prism $rel"
      ok=$((ok + 1))
    fi
  done
else
  log "prism not mounted"
fi
if [ -d /data/app ]; then
  for pkg in com.samsung.android.bixby.agent com.samsung.android.bixby.wakeup com.samsung.android.bixbyvision.framework com.samsung.android.app.settings.bixby com.samsung.android.visionintelligence com.samsung.android.svoiceime com.samsung.sait.bsdservice com.samsung.sait.sohservice com.samsung.android.app.galaxyfinder com.samsung.android.svcagent com.microsoft.appmanager com.samsung.android.game.gametools com.samsung.android.game.gos com.samsung.android.arzone com.samsung.android.aremoji com.samsung.android.aremojieditor com.samsung.android.ardrawing com.samsung.android.visualars com.sec.android.mimage.avatarstickers com.samsung.android.app.camera.sticker.facearavatar.preload com.samsung.android.app.dressroom com.samsung.android.stickercenter com.samsung.android.app.spage com.samsung.android.themestore com.sec.android.app.samsungapps com.sec.android.app.billing com.samsung.android.kidsinstaller com.samsung.android.app.watchmanagerstub com.diotek.sec.lookup.dictionary com.samsung.gpuwatchapp com.sec.android.easyMover com.sec.android.easyMover.Agent com.samsung.android.smartswitchassistant com.touchtype.swiftkey com.swiftkey.swiftkeyconfigurator com.samsung.android.scloud com.samsung.android.forest com.samsung.android.mdx com.samsung.android.app.tips; do
    find /data/app -mindepth 2 -maxdepth 2 -type d 2>/dev/null | while read -r dir; do
      base=${dir##*/}
      case "$base" in
        "$pkg"|"$pkg"-*) rm -rf "$dir"; log "data $pkg" ;;
      esac
    done
    rm -rf "/data/data/$pkg" "/data/user/0/$pkg" "/data/user_de/0/$pkg"
  done
else
  log "data not mounted"
fi
sync
log "extra samsung $ok"
exit 0
